'use strict';

const Translator = require('../components/translator.js');

module.exports = function (app) {
  
  const translator = new Translator();

  app.route('/api/translate')
    .post((req, res) => {
      //console.log(req.body);
	  //return;
	  if(Object.keys(req.body).length < 2){
		res.send({ error: 'Required field(s) missing' });
		return;
	  }
	  if(!req.body.text){
		res.send({"error":"No text to translate"});
		return;
	  }
	  
	  let translatedText = '';
	  
	  //translate from american to british
	  if(req.body.locale === 'american-to-british'){
		translatedText = translator.americanToBritish(req.body.text);
		res.send({text: req.body.text, translation: translatedText});
		return;
	  }
	  
	  //translate from british to american
	  if(req.body.locale === 'british-to-american'){
		translatedText = translator.britishToAmerican(req.body.text);
		res.send({text: req.body.text, translation: translatedText});
		return;
	  }
	  
	  res.send({ error: 'Invalid value for locale field' });
	  return;
    });
};
