const chai = require('chai');
const chaiHttp = require('chai-http');
const assert = chai.assert;
const server = require('../server.js');

chai.use(chaiHttp);

let Translator = require('../components/translator.js');

suite('Functional Tests', () => {
    test('Test: POST request to /api/translate', function(done) {
		chai.request(server)
			.post('/api/translate')
			.send({
				text: 'Mangoes are my favorite fruit.',
				locale: 'american-to-british'
			})
			.end((err, res)=>{
				assert.equal(res.status, 200);
				assert.isObject(res.body);
				assert.strictEqual(res.body.text, 'Mangoes are my favorite fruit.');
				assert.strictEqual(res.body.translation, 'Mangoes are my <span class="highlight">favourite</span> fruit.');
				done();
			});
    });
    test('Test with text and invalid locale field: POST request to /api/translate', function(done) {
		chai.request(server)
			.post('/api/translate')
			.send({
				text: 'Mangoes are my favorite fruit.',
				locale: 'american-to-bri'
			})
			.end((err, res)=>{
				assert.equal(res.status, 200);
				assert.isObject(res.body);
				assert.strictEqual(res.body.error, 'Invalid value for locale field');
				done();
			});
    });
    test('Test with missing text field: POST request to /api/translate', function(done) {
		chai.request(server)
			.post('/api/translate')
			.send({
				locale: 'american-to-british'
			})
			.end((err, res)=>{
				assert.equal(res.status, 200);
				assert.isObject(res.body);
				assert.strictEqual(res.body.error, "Required field(s) missing");
				done();
			});
    });
    test('Test with missing locale field: POST request to /api/translate', function(done) {
		chai.request(server)
			.post('/api/translate')
			.send({
				text: 'Mangoes are my favorite fruit.'
			})
			.end((err, res)=>{
				assert.equal(res.status, 200);
				assert.isObject(res.body);
				assert.strictEqual(res.body.error, 'Required field(s) missing');
				done();
			});
    });
    test('Test with empty text: POST request to /api/translate', function(done) {
		chai.request(server)
			.post('/api/translate')
			.send({
				text: '',
				locale: 'american-to-british'
			})
			.end((err, res)=>{
				assert.equal(res.status, 200);
				assert.isObject(res.body);
				assert.strictEqual(res.body.error, "No text to translate");
				done();
			});
    });
	test('Test with empty text: POST request to /api/translate', function(done) {
		chai.request(server)
			.post('/api/translate')
			.send({
				text: 'Mangoes are my favorite fruit.',
				locale: 'british-to-american'
			})
			.end((err, res)=>{
				assert.equal(res.status, 200);
				assert.isObject(res.body);
				assert.strictEqual(res.body.translation, "Everything looks good to me!");
				done();
			});
    });
});
