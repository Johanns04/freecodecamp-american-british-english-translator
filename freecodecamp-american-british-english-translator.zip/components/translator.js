const americanOnly = require('./american-only.js');
const americanToBritishSpelling = require('./american-to-british-spelling.js');
const americanToBritishTitles = require("./american-to-british-titles.js")
const britishOnly = require('./british-only.js')

class Translator {
	//use americanOnly, american-to-british-spelling, american-to-british-titles
	americanToBritish(textToTranslate){
		//if no text is provided
		if(!textToTranslate){
			return {"error":"No text to translate"};
		}
		
		let workingText = textToTranslate.charAt(0).toUpperCase() + textToTranslate.slice(1);
		let toReplace = {};
		let translatedText = workingText;
		
		//to Replace all the american words
		for(let word in americanOnly){
			let wordRe = '\\b'+word+'\\b';
			let regWord = new RegExp(wordRe, 'gi');
			if(regWord.test(workingText)){
				toReplace[word] = americanOnly[word];
			}
		}
		
		//to replace all the words from american-to-british-spelling
		for(let word in americanToBritishSpelling){
			let wordRe = '\\b'+word+'\\b';
			let regWord = new RegExp(wordRe, 'gi');
			if(regWord.test(workingText)){
				toReplace[word] = americanToBritishSpelling[word];
			}
		}
		
		//to replace american titles
		for(let word in americanToBritishTitles){
			let wordRe = '\\b'+word.replace('.', '\\b\\.');
			let regWord = new RegExp(wordRe, 'gi');
			//console.log(wordRe, regWord);
			if(regWord.test(workingText)){
				toReplace[word] = americanToBritishTitles[word];
			}
		}
		//if no change is needed
		if(!Object.keys(toReplace).length && !/\b\d{1,2}\:\d\d\b/g.test(translatedText)){
			return "Everything looks good to me!";
		}
		//finish the translation
		for(let word in toReplace){
			let regWord = new RegExp(word, 'gi');
			//console.log(regWord, toReplace[word]);
			translatedText = translatedText.replace(regWord, '<span class="highlight">'+toReplace[word]+'</span>');
		}
		//from american time to british
		if(/\b\d{1,2}\:\d\d\b/g.test(translatedText)){
			let time = translatedText.match(/\b\d{1,2}\:\d\d\b/g);
			for(let i=0; i<time.length; i++){
				let replaceTime = '<span class="highlight">' + time[i].replace(/\:/g, '.') + '</span>';
				translatedText = translatedText.replace(time[i], replaceTime);
			}
		}
		return translatedText;
	}
	
	//use british-only, reverse american-to-british-spelling, reverse american-to-british-titles
	britishToAmerican(textToTranslate){
		//if no text is provided
		if(!textToTranslate){
			return {"error":"No text to translate"};
		}

		let workingText = textToTranslate.charAt(0).toUpperCase() + textToTranslate.slice(1);
		let toReplace = {};
		let translatedText = workingText;
		
		//replace all the words that are british only
		for(let word in britishOnly){
			let wordRe = '\\b'+word+'\\b';
			let regWord = new RegExp(wordRe, 'gi');
			if(regWord.test(workingText)){
				toReplace[word] = britishOnly[word];
			}
		}
		//britsh to american spelling
		for(let word in americanToBritishSpelling){
			let wordRe = '\\b'+americanToBritishSpelling[word]+'\\b';
			let regWord = new RegExp(wordRe, 'gi');
			if(regWord.test(workingText)){
				toReplace[americanToBritishSpelling[word]] = word;
			}
		}
		//british to american titles
		for(let title in americanToBritishTitles){
			//it's possible to do this for all the words but it looks unnessarcy for the project
			let word = '\\b' + americanToBritishTitles[title] + '\\b';
			let regWord = new RegExp(word, 'gi');
			if(regWord.test(workingText)){
				toReplace[americanToBritishTitles[title]] = title;
			}
		}
		
		//if no change is needed
		if(!Object.keys(toReplace).length && !/\b\d{1,2}\.\d\d\b/g.test(translatedText)){
			return "Everything looks good to me!";
		}
		//finish the translation
		for(let word in toReplace){
			//if you want to remove the double .. in Mr.. for example put a if statement here
			let regWord = new RegExp(word, 'gi');
			translatedText = translatedText.replace(regWord, '<span class="highlight">'+toReplace[word]+'</span>');
		}
		
		//replace the time from british to american
		if(/\b\d{1,2}\.\d\d\b/g.test(translatedText)){
			let time = translatedText.match(/\b\d{1,2}\.\d\d\b/g);
			for(let i=0; i<time.length; i++){	
				let replaceTime = '<span class="highlight">' + time[i].replace(/\./g, ':') + '</span>';
				translatedText = translatedText.replace(time[i], replaceTime);
			}
		}
		
		return translatedText;
	}
}

module.exports = Translator;