module.exports = {
  'Mr.': 'Mr',
  'Mrs.': 'Mrs',
  'Ms.': 'Ms',
  'Mx.': 'Mx',
  'Dr.': 'Dr',
  'Prof.': 'Prof'
}
